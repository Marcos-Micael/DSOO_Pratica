/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.marcos.exposicao.model;

import java.sql.Date;

/**
 *
 * @author 202312030002
 */
public class Escultura {
    
    private String titulo;
    private int idObra;
    private Date dataAquisicao;
    private String dimensoes;
    private String material;

    public Escultura(String titulo, int idObra, Date dataAquisicao, String dimensoes, String material) {
        this.titulo = titulo;
        this.idObra = idObra;
        this.dataAquisicao = dataAquisicao;
        this.dimensoes = dimensoes;
        this.material = material;
    }

    public Escultura(String titulo, Date dataAquisicao, String dimensoes, String material) {
        this.titulo = titulo;
        this.dataAquisicao = dataAquisicao;
        this.dimensoes = dimensoes;
        this.material = material;
    }

    public Escultura() {
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getIdObra() {
        return idObra;
    }

    public void setIdObra(int idObra) {
        this.idObra = idObra;
    }

    public Date getDataAquisicao() {
        return dataAquisicao;
    }

    public void setDataAquisicao(Date dataAquisicao) {
        this.dataAquisicao = dataAquisicao;
    }

    public String getDimensoes() {
        return dimensoes;
    }

    public void setDimensoes(String dimensoes) {
        this.dimensoes = dimensoes;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    
    
    
}
