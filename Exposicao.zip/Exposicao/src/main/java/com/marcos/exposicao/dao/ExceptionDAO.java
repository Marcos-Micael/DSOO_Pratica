/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.marcos.exposicao.dao;

/**
 *
 * @author 202312030002
 */
public class ExceptionDAO extends Exception {
    
    public ExceptionDAO(String mensagem){
        super(mensagem);
    }
}
