/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.marcos.exposicao.dao;

import com.marcos.exposicao.model.Pintura;
import com.marcos.exposicao.model.Artista;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author 202312030002
 */
public class PinturaDAO {

    Connection connection = null;
    PreparedStatement preparedStatement = null;

    public void cadastrarPintura(Pintura pintura) throws ExceptionDAO {
        try {
            String strSQL = "insert into obra (titulo, dimensoes, data_aquisicao, tipo_Tinta, idArtista)" + " values (?,?,?,?,?);";
            connection = new ConexaoBanco().getConnection();

            if (connection != null) {
                preparedStatement = connection.prepareStatement(strSQL);
                preparedStatement.setString(1, pintura.getTitulo());
                preparedStatement.setString(2, pintura.getDimensoes());
                preparedStatement.setString(3, pintura.getDataAquisicao());
                preparedStatement.setString(4, pintura.getTipoTinta());
                preparedStatement.setInt(5, pintura.getIdArtista());
                preparedStatement.execute();
            }
        } catch(SQLException e) {
            throw new ExceptionDAO("Erro ao tentar cadastrar pintura:" + e);
        } finally{
            ConexaoBanco.fecharPreparedStatement(preparedStatement);
            ConexaoBanco.fecharConexao(connection);
        }
    }
}
